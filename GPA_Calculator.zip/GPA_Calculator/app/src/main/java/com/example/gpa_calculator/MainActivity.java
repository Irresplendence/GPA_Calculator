package com.example.gpa_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Buttons and whatnot

     TextView gpa;
     Button  calculate;
     EditText tf_course1, tf_course2, tf_course3, tf_course4, tf_course5;
     double result_num;
     double c1, c2, c3, c4, c5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Variable Declaration


        calculate = findViewById(R.id.b_calculate);


        tf_course1 = (EditText) findViewById(R.id.tf_course1);
        tf_course2 = (EditText) findViewById(R.id.tf_course2);
        tf_course3 = (EditText) findViewById(R.id.tf_course3);
        tf_course4 = (EditText) findViewById(R.id.tf_course4);
        tf_course5 = (EditText) findViewById(R.id.tf_course5);

        // Used to disable the buttons if the fields are empty. (Revisit)

        tf_course1.addTextChangedListener(courseWatcher);
        tf_course2.addTextChangedListener(courseWatcher);
        tf_course3.addTextChangedListener(courseWatcher);
        tf_course4.addTextChangedListener(courseWatcher);
        tf_course5.addTextChangedListener(courseWatcher);


        calculate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){  // When Calculate is clicked..
                c1 = Double.parseDouble(tf_course1.getText().toString()); //  Possibly stop parsing it to a string? Maybe that's why it's not calculating.
                c2 = Double.parseDouble(tf_course2.getText().toString());
                c3 = Double.parseDouble(tf_course3.getText().toString());
                c4 = Double.parseDouble(tf_course4.getText().toString());
                c5 = Double.parseDouble(tf_course5.getText().toString());

                result_num = (c1 + c2 + c3 + c4 + c5)/5.0;      // Could use a variable for the division portion
                if(result_num <= 100.0 &&  result_num >= 93.0){
                    gpa.setText("A or 4.0");
                }else if(result_num <= 92.0 && result_num >= 90.0){   // Possible to change the android background property based off of the if statement?
                    gpa.setText("A- or 3.67");
                }else if(result_num <= 89.0 && result_num >= 87.0){
                    gpa.setText("B+ or 3.33");
                }else if(result_num <= 86.0 && result_num >= 83.0){
                    gpa.setText("B or 3.0");
                }else if(result_num <= 82.0 && result_num >= 80.0) {

                    gpa.setText("B- or 2.67");
                }else if(result_num <= 79.0 && result_num >= 77.0) {
                    gpa.setText("C+ or 2.33");
                }else if(result_num <= 76.0 && result_num >= 73.0) {
                    gpa.setText("C- or 1.67");
                }else if(result_num <= 72.0 && result_num >= 70.0) {
                    gpa.setText("D+ or 1.33");
                }else if(result_num <= 69.0 && result_num >= 65.0) {
                    gpa.setText("");
                }else if(result_num <= 64.0 && result_num >= 60.0){
                    gpa.setText("D or 1.0");

            }



        }


    });


    }

    private TextWatcher courseWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }
// Basically used to see if any of the values are empty, and if they are, then the Calculate button SHOULD be disabled. (Of course this isn't working) 
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            // Takes the values from the Enter GPA fields and makes them parsable.
            String course1 = tf_course1.getText().toString();
            String course2 = tf_course1.getText().toString();
            String course3 = tf_course1.getText().toString();
            String course4 = tf_course1.getText().toString();
            String course5 = tf_course1.getText().toString();


            calculate.setEnabled(!course1.isEmpty() && !course2.isEmpty() && !course3.isEmpty() && !course4.isEmpty() && !course5.isEmpty());



        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
}
